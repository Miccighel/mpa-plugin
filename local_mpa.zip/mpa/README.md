# mpa-plugin
A plugin for Moodle e-learning platform to implement the peer assessment activity into another way compared to "Workshop" module.

For a reference about how the peer assessment is implemented is this plugin, see (in Italian):

A. Girardi, La valutazione nell'e-learning: proposta, implementazione e valutazione sperimentale di un metodo innovativo basato sul peer-assessment (2007), University of Udine.
